"""Compile the sample network, call native search for each branch case, and verify it."""

import argparse
from collections import Counter
from contextlib import ExitStack
from hashlib import sha256
import gzip
import json
from pathlib import Path
from tempfile import TemporaryDirectory

from model import evidence, normalize
from native import native_solve
from roster import roster, scenarios

ROOT = Path(__file__).resolve().parent
ENGINE = "cddfdaee5b9ee9ff2577399726b95a12286e69c7"
OUTPUTS = ("raw-scenarios.ndjson.gz", "normalized-problems.ndjson.gz",
           "verified-output.ndjson.gz", "assignments.ndjson.gz")


def encoded(value, *, compact=False):
    options = {"separators": (",", ":")} if compact else {"indent": 2}
    return (json.dumps(value, **options, ensure_ascii=False, allow_nan=False) + "\n").encode()


def validate_roster(raw):
    branches = raw["branches"]
    assert len(branches) == len({b["branch_id"] for b in branches}) == 5
    seen = set()
    for branch in branches:
        groups = branch["departments"]
        assert len(groups) == len({d["department_id"] for d in groups}) == 4
        for department in groups:
            assert len(department["operators"]) == 25
            for operator in department["operators"]:
                assert operator["operator_id"] not in seen
                seen.add(operator["operator_id"])
                assert set(operator) == {"operator_id", "home_department", "task_skills",
                    "language_proficiency", "role_months", "capability_tags", "parallel_contact_limit",
                    "shift", "breaks"}
                assert operator["home_department"] == department["department_id"]
                assert all(type(rating) is int and 1 <= rating <= 5 for rating in
                           (*operator["task_skills"].values(), *operator["language_proficiency"].values()))
                assert type(operator["role_months"]) is int and 0 <= operator["role_months"] <= 120
                limits = operator["parallel_contact_limit"]
                assert set(limits) == {"voice", "chat"}
                assert type(limits["voice"]) is int and 0 <= limits["voice"] <= 1
                assert type(limits["chat"]) is int and 0 <= limits["chat"] <= 3
    assert len(seen) == 500


def generate(output, lib):
    raw = roster()
    validate_roster(raw)
    (output / "roster.json").write_bytes(encoded(raw))
    results = []
    counts = Counter()
    distinct_plans = set()
    with ExitStack() as stack:
        files = [stack.enter_context((output / name).open("wb")) for name in OUTPUTS]
        gzips = [stack.enter_context(gzip.GzipFile(filename="", mode="wb", fileobj=f, mtime=0)) for f in files]

        def emit(index, row):
            gzips[index].write(encoded(row, compact=True))
            counts[OUTPUTS[index]] += 1

        for branch in raw["branches"]:
            branch_id = branch["branch_id"]
            for case in scenarios(branch):
                problem_info = normalize(branch, case)
                problem = problem_info[0]
                native = native_solve(lib, problem, case["evaluation_budget"])
                report = evidence(branch, case, problem_info, native)
                results.append(report)
                distinct_plans.add((branch_id, report["proof"]["budget"], tuple(native["values"])))
                emit(0, case)
                emit(1, {"scenario_id": case["scenario_id"], "branch_id": branch_id,
                         "operator_index_order": [op["operator_id"] for op in problem_info[1]],
                         "evaluation_budget": case["evaluation_budget"], "problem": problem})
                emit(2, report)
                for row in report["assignments"]:
                    emit(3, {"scenario_id": case["scenario_id"], "branch_id": branch_id, **row})

    candidates = [r["proof"]["evaluated_combinations"] for r in results]
    selected = [a for result in results for a in result["assignments"]]
    by_channel = Counter(a["channel"] for a in selected)
    by_branch = []
    for branch in raw["branches"]:
        branch_id = branch["branch_id"]
        own = [r for r in results if r["branch_id"] == branch_id]
        by_branch.append({"branch_id": branch_id, "location_context": branch["location_context"],
                          "timezone": branch["timezone"], "departments": 4, "operator_profiles": 100,
                          "independent_scenarios": len(own),
                          "covered_positions": sum(r["queues_covered"] for r in own),
                          "evaluated_combinations": sum(r["proof"]["evaluated_combinations"] for r in own)})
    artifacts = []
    for name in ("roster.json", *OUTPUTS):
        download = (output / name).read_bytes()
        body = gzip.decompress(download) if name in OUTPUTS else download
        artifacts.append({"path": name, "encoding": "gzip" if name in OUTPUTS else "identity",
                          "records": counts[name] if name in OUTPUTS else 1,
                          "download_bytes": len(download), "download_sha256": sha256(download).hexdigest(),
                          "uncompressed_bytes": len(body), "uncompressed_sha256": sha256(body).hexdigest()})
    summary = {
        "batch_id": raw["dataset_id"], "classification": "sample", "schema_version": 1,
        "first_verified_engine_revision": ENGINE, "native_abi_version": 1,
        "scope": "Each branch-window variant is a separate solve; no network-wide scheduling or performance benchmark.",
        "branches": len(raw["branches"]), "departments": 20, "operators": 500,
        "windows_per_branch": 3, "variants_per_window": 4, "independent_scenarios": len(results),
        "positions_per_scenario": 8, "covered_positions": len(selected),
        "assignments_by_channel": dict(sorted(by_channel.items())),
        "distinct_branch_assignment_vectors": len(distinct_plans),
        "distinct_assigned_operator_ids": len({r["assigned_operator_id"] for r in selected}),
        "cross_department_assignments": sum(q["department_id"] != q["operator_home_department"] for q in selected),
        "exact_status_counts": dict(Counter(r["status"] for r in results)),
        "evaluated_combinations": {"total": sum(candidates), "min_per_case": min(candidates), "max_per_case": max(candidates)},
        "hard_feasible_combinations": sum(r["proof"]["hard_feasible_combinations"] for r in results),
        "preferences_met": sum(r["preference_met"] for r in selected),
        "preferences_missed": sum(not r["preference_met"] for r in selected),
        "soft_score_histogram": dict(sorted(Counter(r["native_solution"]["score"]["soft"] for r in results).items())),
        "branch_summary": by_branch, "artifacts": artifacts,
    }
    assert summary["independent_scenarios"] == 60 and len(selected) == 480
    assert summary["cross_department_assignments"] > 0 and summary["preferences_missed"] > 0
    (output / "summary.json").write_bytes(encoded(summary))
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--library", type=Path, required=True)
    parser.add_argument("--write", action="store_true")
    args = parser.parse_args()
    with TemporaryDirectory(dir=ROOT) as directory:
        tmp = Path(directory)
        summary = generate(tmp, args.library)
        for file in tmp.iterdir():
            destination = ROOT / file.name
            if args.write:
                file.replace(destination)
            elif file.read_bytes() != destination.read_bytes():
                raise AssertionError(f"{file.name} does not match native recomputation")
    print(f"{summary['branches']} branches; {summary['operators']} operators; "
          f"{summary['independent_scenarios']} separate exact solves; {summary['covered_positions']} assignments; "
          f"{summary['evaluated_combinations']['total']} evaluated candidates")


if __name__ == "__main__":
    main()
