"""Generate five independent sample branches with 25 profiles per department."""

from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

CITIES = (
    ("NYC", "New York", "America/New_York", "en", "es"),
    ("LON", "London", "Europe/London", "en", "fr"),
    ("FRA", "Frankfurt", "Europe/Berlin", "de", "en"),
    ("TIA", "Tirana", "Europe/Tirane", "sq", "en"),
    ("ROM", "Rome", "Europe/Rome", "it", "en"),
)
DEPARTMENTS = (
    ("billing", "Billing and payments", "billing_review", "billing_adjustment", 12),
    ("accounts", "Account access", "account_recovery", "recovery_workflow", 9),
    ("technical", "Technical support", "technical_diagnostics", "technical_escalation", 6),
    ("customer", "Customer resolutions", "case_resolution", "complaint_handoff", 8),
)
WINDOWS = ("early", "middle", "late")
VARIANTS = ("baseline", "short-break", "coverage-change", "surge-priority")


def time(zone, hour, minute=0):
    return datetime(2026, 11, 16, hour, minute, tzinfo=zone)


def period(zone, start, end):
    result = {}
    for label, point in (("start", start), ("end", end)):
        value = time(zone, *point) if isinstance(point, tuple) else time(zone, point)
        result[label] = value.isoformat(timespec="minutes")
    return result


def roster():
    branches = []
    for code, city, tz, primary, secondary in CITIES:
        zone = ZoneInfo(tz)
        departments = []
        for j, (d, name, skill, capability, _) in enumerate(DEPARTMENTS):
            profiles = []
            for i in range(25):
                group = (i // 3) if i < 9 else i % 3
                shift = period(zone, (7 + 4 * group, 30), (11 + 4 * group, 30))
                breaks = [period(zone, (10 + 4 * group, 30), (10 + 4 * group, 45))]
                skills = {"customer_communication": 2 + (i * 3 + j) % 4, skill: 1 + (i + j) % 3}
                langs = {primary: 3 + (i + j) % 3, secondary: 1 + (i * 2 + j) % 5}
                capability_set = ["case_documentation"]
                capacities = {"voice": i % 4 != 0, "chat": i % 4}
                months = 2 + (i * 11 + j * 5) % 110
                if i < 9:
                    mode = i % 3
                    skills[skill] = 5 if mode == 0 else 4
                    langs = {primary: 5 if mode != 2 else 3, secondary: 5 if mode == 0 else 4}
                    capability_set.append(capability)
                    capacities = {"voice": mode != 2, "chat": (3, 1, 2)[mode]}
                    months = 36 + group * 3 + (2 - mode) * 5 + j
                elif i == 9 and j % 2 == 0:
                    # An approved, cross-trained operator can support their own
                    # department or the next one during the midday interval.
                    _, _, neighbor_skill, neighbor_capability, _ = DEPARTMENTS[j + 1]
                    group = 1
                    shift = period(zone, (11, 30), (15, 30))
                    breaks = [period(zone, (14, 30), (14, 45))]
                    skills.update({skill: 5, neighbor_skill: 5})
                    langs = {primary: 5, secondary: 5}
                    capability_set.extend((capability, neighbor_capability))
                    capacities = {"voice": True, "chat": 3}
                    months = 68 + j
                profiles.append({
                    "operator_id": f"{code}-{d.upper()}-{i+1:02d}", "home_department": d,
                    "task_skills": skills, "language_proficiency": langs, "role_months": months,
                    "capability_tags": capability_set, "parallel_contact_limit": {**capacities, "voice": int(capacities["voice"])},
                    "shift": shift, "breaks": breaks,
                })
            departments.append({"department_id": d, "name": name, "operators": profiles})
        branches.append({"branch_id": code, "location_context": city, "timezone": tz,
                         "service_languages": [primary, secondary], "departments": departments})
    return {
        "schema_version": 1, "classification": "sample", "observed_data": False,
        "dataset_id": "contact-center-five-branch-sample-v1",
        "rating_scale": {"1": "introductory", "2": "supported", "3": "routine", "4": "independent", "5": "advanced"},
        "branches": branches,
    }


def scenarios(branch):
    code = branch["branch_id"]
    zone = ZoneInfo(branch["timezone"])
    row = [city[0] for city in CITIES].index(code)
    primary, secondary = branch["service_languages"]
    for k, window in enumerate(WINDOWS):
        hour = 9 + k * 4
        for v, variation in enumerate(VARIANTS):
            queues = []
            for j, (department, label, skill, capability, experience) in enumerate(DEPARTMENTS):
                for channel, language in (("voice", primary), ("chat", secondary)):
                    emphasis = (j + row + k + v) % 4
                    is_voice = channel == "voice"
                    typical = (2 if is_voice else 3) + emphasis
                    surge = typical + (2 if v != 3 else 4)
                    queues.append({
                        "queue_id": f"{department}-{channel}", "department_id": department,
                        "label": f"{label} ({channel})", "channel": channel,
                        "skill": skill, "min_skill": 4, "language": language, "min_language": 4,
                        "capability": capability, "min_role_months": experience,
                        "min_parallel_contacts": 1 if is_voice else 2,
                        "preference_weight": 6 + (3 if is_voice else 0) + emphasis + (5 if v == 3 and not is_voice else 0),
                        "typical_arrivals": typical, "surge_arrivals": surge,
                        "handling_seconds_per_contact": (300 if is_voice else 205) + 15 * (j + emphasis),
                    })
            changed_department = branch["departments"][(row + k + v) % 4]
            change = changed_department["operators"][k * 3]["operator_id"]
            yield {
                "scenario_id": f"{code}-{window}-{variation}", "branch_id": code, "window_id": window,
                "variant": variation, "coverage_window": period(zone, hour, (hour, 30)),
                "allow_cross_department": v != 2,
                "temporary_unavailability": (
                    {change: [period(zone, (hour, 10), (hour, 20))]} if v == 1 else {}
                ),
                "evaluation_budget": 100000,
                "voice_handling_target_basis_points": 8000,
                "surge_probability_basis_points": (2500, 2500, 2500, 4000)[v],
                "queues": queues,
            }
