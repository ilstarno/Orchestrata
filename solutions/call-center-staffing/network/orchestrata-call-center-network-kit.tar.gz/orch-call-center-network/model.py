"""Filter sample department, training, time, and capability into native domains."""

from collections import Counter
from datetime import datetime
from itertools import product
from math import prod


def period(data):
    times = tuple(datetime.fromisoformat(data[key]) for key in ("start", "end"))
    if times[0].utcoffset() is None or times[1].utcoffset() is None or times[0] >= times[1]:
        raise ValueError("invalid timezone-aware period")
    return times


def intersects(first, second):
    return first[0] < second[1] and second[0] < first[1]


def filters(q, operator, sample, window):
    skill = operator["task_skills"].get(q["skill"], 0)
    language = operator["language_proficiency"].get(q["language"], 0)
    experience = operator["role_months"]
    channel_capacity = operator["parallel_contact_limit"][q["channel"]]
    qualified = q["capability"] in operator["capability_tags"]
    shift = period(operator["shift"])
    covered = shift[0] <= window[0] and window[1] <= shift[1]
    breaks = operator["breaks"] + sample["temporary_unavailability"].get(operator["operator_id"], [])
    blocked = any(intersects(period(b), window) for b in breaks)
    department_ok = operator["home_department"] == q["department_id"] or sample["allow_cross_department"]
    facts = {"skill_rating": skill, "language_rating": language, "role_months": experience,
             "parallel_contact_limit": channel_capacity, "capability_confirmed": qualified,
             "covers_entire_window": covered, "break_overlaps_window": blocked,
             "department_transfer_permitted": department_ok}
    exclusions = [reason for condition, reason in (
        (not department_ok, "department_transfer_disabled"),
        (not covered, "shift_does_not_cover_window"), (blocked, "break_overlaps_window"),
        (skill < q["min_skill"], "task_proficiency_below_minimum"),
        (language < q["min_language"], "service_language_below_minimum"),
        (experience < q["min_role_months"], "role_experience_below_minimum"),
        (not qualified, "required_capability_missing"),
        (channel_capacity < q["min_parallel_contacts"], "insufficient_channel_capacity"),
    ) if condition]
    return facts, exclusions


def normalize(branch, sample):
    roster = [op for dept in branch["departments"] for op in dept["operators"]]
    ids = [op["operator_id"] for op in roster]
    if len(roster) != 100 or len(set(ids)) != 100 or sample["branch_id"] != branch["branch_id"]:
        raise ValueError("incorrect roster or scenario branch")
    window = period(sample["coverage_window"])
    variables, screens, preferences = [], [], []
    for q in sample["queues"]:
        domains, evidence, excluded = [], {}, {}
        for i, operator in enumerate(roster):
            facts, exclusions = filters(q, operator, sample, window)
            if exclusions:
                excluded[ids[i]] = exclusions
            else:
                domains.append(i)
                evidence[i] = facts
        if not domains:
            raise ValueError(f"no qualified operators for {q['queue_id']}")
        preferred = min(domains, key=lambda i: (
            -evidence[i]["skill_rating"], -evidence[i]["language_rating"],
            -evidence[i]["role_months"], ids[i],
        ))
        preferences.append({"kind": "prefer_value", "variable": len(variables),
                            "value": preferred, "soft_weight": q["preference_weight"]})
        variables.append({"name": q["queue_id"], "domain": domains})
        screens.append((evidence, excluded, preferred))
    combinations = prod(len(v["domain"]) for v in variables)
    if combinations > sample["evaluation_budget"]:
        raise ValueError("case outside exact evaluation budget")
    problem = {"variables": variables, "constraints": [
        {"kind": "all_different", "variables": list(range(len(variables))), "hard_weight": 1},
        *preferences,
    ]}
    return problem, roster, screens, combinations, int((window[1] - window[0]).total_seconds())


def oracle(problem):
    domains = (v["domain"] for v in problem["variables"])
    rules = problem["constraints"][1:]
    feasible, best = 0, None
    for choice in product(*domains):
        if len(choice) != len(set(choice)):
            continue
        feasible += 1
        score = -sum(rule["soft_weight"] for i, rule in enumerate(rules) if choice[i] != rule["value"])
        if best is None or score > best[1]:
            best = (choice, score)
    return best, feasible


def demand_context(q, sample, duration):
    spike = sample["surge_probability_basis_points"]
    typical_work = q["typical_arrivals"] * q["handling_seconds_per_contact"]
    surge_work = q["surge_arrivals"] * q["handling_seconds_per_contact"]
    weighted = (10000 - spike) * typical_work + spike * surge_work
    details = {"handling_seconds_per_contact": q["handling_seconds_per_contact"],
               "scenarios": {"typical": {"arrivals": q["typical_arrivals"], "probability_basis_points": 10000 - spike,
                                         "handling_seconds": typical_work},
                             "surge": {"arrivals": q["surge_arrivals"], "probability_basis_points": spike,
                                       "handling_seconds": surge_work}},
               "expected_handling_seconds": weighted / 10000,
               "used_by_native_solver": False}
    if q["channel"] == "voice":
        capacity = duration * sample["voice_handling_target_basis_points"] // 10000
        details.update({"planning_target_handling_seconds": capacity,
                        "probability_above_target_basis_points": (10000 - spike if typical_work > capacity else 0)
                        + (spike if surge_work > capacity else 0)})
    else:
        details["raw_metric_scope"] = "contact-seconds; not operator occupancy or queue delay"
    return details


def evidence(branch, sample, normalized, native):
    problem, roster, screens, combinations, duration = normalized
    optimal, feasible = oracle(problem)
    if not optimal or native != {"values": list(optimal[0]), "score": {"hard": 0, "soft": optimal[1]},
                                 "evaluated": combinations}:
        raise AssertionError("native result and exhaustive verifier disagree")
    output = []
    for index, (queue, chosen, screen) in enumerate(zip(sample["queues"], native["values"], screens, strict=True)):
        facts, excluded, preferred = screen
        output.append({
            "queue_id": queue["queue_id"], "department_id": queue["department_id"], "channel": queue["channel"],
            "assigned_operator_id": roster[chosen]["operator_id"], "normalized_operator_index": chosen,
            "operator_home_department": roster[chosen]["home_department"],
            "eligible_candidate_count": len(facts), "selected_eligibility": facts[chosen],
            "excluded_candidate_count": len(excluded),
            "exclusion_reason_counts": dict(sorted(Counter(r for reasons in excluded.values() for r in reasons).items())),
            "preferred_operator_id": roster[preferred]["operator_id"], "preference_weight": queue["preference_weight"],
            "preference_met": chosen == preferred, "soft_penalty": 0 if chosen == preferred else -queue["preference_weight"],
            "demand_context": demand_context(queue, sample, duration),
        })
    return {"scenario_id": sample["scenario_id"], "branch_id": branch["branch_id"],
            "status": "optimal_within_model", "coverage_window": sample["coverage_window"],
            "queues_requested": len(output), "queues_covered": len(output),
            "verdicts": {"all_selected_operators_eligible": True, "simultaneous_assignments_distinct": True},
            "native_solution": native, "proof": {
                "budget": sample["evaluation_budget"], "candidate_combinations": combinations,
                "evaluated_combinations": native["evaluated"], "hard_feasible_combinations": feasible,
                "independent_exact_oracle_agrees": True,
            }, "assignments": output}
