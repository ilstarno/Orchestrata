"""Native ABI v1 solve call for checked-in sample data."""

from ctypes import CDLL, POINTER, byref, c_char_p, c_int32, c_size_t, c_uint32, c_uint64, c_void_p, string_at
import json


def require(condition, message):
    if not condition:
        raise ValueError(message)


def native_solve(path, problem, budget):
    library = CDLL(str(path.resolve(strict=True)))
    abi = library.orchestrata_abi_version
    abi.argtypes, abi.restype = [], c_uint32
    require(abi() == 1, "requires native ABI v1")
    solve = library.orchestrata_solve_json_v1
    solve.argtypes = [c_char_p, c_size_t, c_uint64, POINTER(c_void_p)]
    solve.restype = c_int32
    free = library.orchestrata_free_json_v1
    free.argtypes, free.restype = [c_void_p], None
    request = json.dumps(problem, separators=(",", ":")).encode("utf-8")
    out = c_void_p()
    status = solve(request, len(request), budget, byref(out))
    try:
        require(status == 0 and bool(out), f"native solve failed (status {status})")
        result = json.loads(string_at(out))["solution"]
    finally:
        free(out)
    require(result is not None, "native solver proved this sample has no feasible coverage")
    return result

