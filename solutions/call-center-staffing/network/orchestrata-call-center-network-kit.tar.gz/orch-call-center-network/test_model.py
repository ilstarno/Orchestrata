import unittest

from build import validate_roster
from model import demand_context, normalize
from roster import roster, scenarios


class ModelTests(unittest.TestCase):
    def test_five_four_twenty_five_and_strictly_separate_operator_sets(self):
        source = roster()
        validate_roster(source)
        branches = source["branches"]
        ids = set()
        for branch in branches:
            models = list(scenarios(branch))
            self.assertEqual(len(models), 12)
            for window in models:
                problem, profiles, _, size, duration = normalize(branch, window)
                self.assertEqual(len(profiles), 100)
                self.assertTrue(all(op["operator_id"].startswith(branch["branch_id"] + "-") for op in profiles))
                self.assertEqual((len(problem["variables"]), duration), (8, 1800))
                self.assertLessEqual(size, 100000)
            ids.update(op["operator_id"] for op in profiles)
        self.assertEqual(len(ids), 500)

    def test_transfer_and_temporary_break_change_midday_domains(self):
        branch = roster()["branches"][0]
        samples = {s["scenario_id"]: s for s in scenarios(branch)}
        regular = normalize(branch, samples["NYC-middle-baseline"])
        changed = normalize(branch, samples["NYC-middle-short-break"])
        local_only = normalize(branch, samples["NYC-middle-coverage-change"])
        self.assertNotEqual(changed[0]["variables"], regular[0]["variables"])
        self.assertNotEqual(local_only[0]["variables"], regular[0]["variables"])
        for queue, variable in zip(samples["NYC-middle-baseline"]["queues"], local_only[0]["variables"]):
            self.assertTrue(all(local_only[1][i]["home_department"] == queue["department_id"] for i in variable["domain"]))

    def test_demand_is_separate_and_chat_is_not_operator_occupancy(self):
        branch = roster()["branches"][0]
        sample = next(scenarios(branch))
        normalized = normalize(branch, sample)[0]
        sample["surge_probability_basis_points"] = 8000
        self.assertEqual(normalize(branch, sample)[0], normalized)
        voice, chat = (demand_context(q, sample, 1800) for q in sample["queues"][:2])
        self.assertIn("probability_above_target_basis_points", voice)
        self.assertNotIn("probability_above_target_basis_points", chat)
        self.assertFalse(voice["used_by_native_solver"] or chat["used_by_native_solver"])

if __name__ == "__main__":
    unittest.main()
