"""Check archive hashes, scenario correspondence, and flattened assignment totals."""

from collections import Counter
import gzip
from hashlib import sha256
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent


def verify():
    summary = json.loads((HERE / "summary.json").read_bytes())
    verified = {}
    for artifact in summary["artifacts"]:
        data = (HERE / artifact["path"]).read_bytes()
        assert sha256(data).hexdigest() == artifact["download_sha256"]
        assert len(data) == artifact["download_bytes"]
        decoded = gzip.decompress(data)
        assert sha256(decoded).hexdigest() == artifact["uncompressed_sha256"]
        assert len(decoded) == artifact["uncompressed_bytes"]
        rows = [json.loads(line) for line in decoded.splitlines()]
        assert len(rows) == artifact["records"]
        verified[artifact["path"]] = rows

    identifier = [f"CC-{i + 1:03d}" for i in range(summary["scenarios"])]
    for filename, rows in verified.items():
        if filename != "assignments.ndjson.gz":
            assert [r["scenario_id"] for r in rows] == identifier

    outcome = verified["native-solutions.ndjson.gz"]
    proof = verified["enriched-output.ndjson.gz"]
    normalized = verified["normalized-problems.ndjson.gz"]
    flattened = verified["assignments.ndjson.gz"]
    assert len(flattened) == summary["covered_queue_assignments"]
    assert Counter(r["status"] for r in outcome) == Counter(summary["scenario_status_counts"])
    assert sum(r["solution"]["evaluated"] for r in outcome) == summary["candidate_combinations_evaluated"]["total"]
    assert len({tuple(r["solution"]["values"]) for r in outcome}) == summary["distinct_assignment_vectors"]
    assert len({json.dumps(row["problem"], sort_keys=True) for row in normalized}) == summary["distinct_normalized_problems"]
    assert sum(row["preference_met"] for row in flattened) == summary["soft_preferences"]["satisfied"]
    assert sum(not row["preference_met"] for row in flattened) == summary["soft_preferences"]["missed"]
    width = summary["queues_per_scenario"]
    for i, (native, raw_evidence, finite) in enumerate(zip(outcome, proof, normalized, strict=True)):
        assignment = native["solution"]
        audit = raw_evidence["report"]
        subset = flattened[i * width:(i + 1) * width]
        assert audit["proof"]["independent_enumeration_matches_native"]
        assert all(row["scenario_id"] == native["scenario_id"] for row in subset)
        assert [row["operator_id"] for row in subset] == [q["assigned_operator"] for q in audit["queues"]]
        assert [row["native_value"] for row in subset] == assignment["values"]
        assert all(value in v["domain"] for value, v in zip(assignment["values"], finite["problem"]["variables"], strict=True))
        assert len(set(assignment["values"])) == width
        assert sum(row["assigned_queue_soft_penalty"] for row in subset) == assignment["score"]["soft"]

    print(f"{len(verified)} archive hashes verified; {len(outcome)} cases and {len(flattened)} assignments reconcile")


if __name__ == "__main__":
    verify()
