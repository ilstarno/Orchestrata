"""Reproduce 240 separate sample call-center coverage decisions and their audit records."""

import argparse
from collections import Counter
from copy import deepcopy
import gzip
import hashlib
import json
from pathlib import Path
import sys
from tempfile import TemporaryDirectory

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / "common"))
from make_sample import make_sample, period
from normalize import normalize, require
from reproduce import enrich, native_solve

SCENARIO_COUNT = 240
THREE_OPERATOR_GROUPS = ((3, 4, 5), (6, 7, 8), (9, 10, 11), (12, 13, 14))
ARCHIVES = ("raw-input.ndjson.gz", "normalized-problems.ndjson.gz",
            "native-solutions.ndjson.gz", "enriched-output.ndjson.gz", "assignments.ndjson.gz")
SOURCE_REVISION = "cddfdaee5b9ee9ff2577399726b95a12286e69c7"


def stable_hash(data):
    return hashlib.sha256(data).hexdigest()


def json_line(value):
    return (json.dumps(value, ensure_ascii=False, separators=(",", ":"), allow_nan=False) + "\n").encode()


def profile(seed, template):
    # A small explicit modular design keeps the samples reproducible across
    # languages and interpreter versions, without claiming actual observed variation.
    raw = deepcopy(template)
    identifier = f"CC-{seed + 1:03d}"
    raw["dataset_id"] = f"call-center-coverage-sample-batch-v1-{identifier}"
    raw["metadata"]["generated_by"] = "batch.py v1"
    odds = (1500, 2250, 3000, 3750, 4500)[seed % 5]
    raw["policy"]["demand_scenarios_basis_points"] = {"typical": 10000 - odds, "surge": odds}
    raw["policy"]["voice_occupancy_target_basis_points"] = (7500, 8000, 8500)[(seed // 5) % 3]
    for i, queue in enumerate(raw["queues"]):
        queue["soft_preference_weight"] = 3 + (seed * (2 * i + 3) + 7 * i + seed // (i + 2)) % 12
        typical = 1 + (seed * (i + 2) + i + seed // (i + 1)) % 4
        queue["arrival_counts"] = {"typical": typical, "surge": typical + 1 + (seed + i * 3) % 4}
        queue["average_handle_seconds"] += 15 * ((seed + i * 3) % 7 - 3)

    changes = []
    def unavailable(index, variant):
        operator = raw["operators"][index]
        if variant % 2:
            operator["breaks"].append(period(10, 10, 10, 20))
            change = "break_added_inside_window"
        else:
            operator["contact_capacity"]["voice"] = 0
            change = "voice_seat_unavailable"
        changes.append({"operator_id": operator["id"], "change": change})

    # Coupled billing: leave the first three operators covering all eligibility
    # patterns except that at most one may be unavailable. Every case retains
    # one Spanish-qualified and one distinct billing-qualified operator.
    billing = seed % 4
    if billing:
        unavailable(billing - 1, seed // 4)
    # Other queues have three candidates each. Up to two temporary changes per
    # group keep at least one eligible operator for the modeled window.
    for i, group in enumerate(THREE_OPERATOR_GROUPS):
        mode = (seed // (3 ** i) + seed // (7 + i) + i) % 5
        if mode:
            unavailable(group[(mode - 1) % 3], seed + i)
        if mode == 4:
            unavailable(group[1], seed + i + 1)
    return identifier, raw, changes


class Archive:
    """One gzip-compressed UTF-8 NDJSON stream; track both byte checksums."""

    def __init__(self, directory, name):
        self.path = directory / name
        self.logical_hash = hashlib.sha256()
        self.logical_bytes = 0
        self.records = 0

    def __enter__(self):
        self.file = self.path.open("wb")
        self.stream = gzip.GzipFile(filename="", fileobj=self.file, mode="wb", compresslevel=9, mtime=0)
        return self

    def __exit__(self, *error):
        self.stream.close()
        self.file.close()

    def write(self, record):
        encoded = json_line(record)
        self.stream.write(encoded)
        self.logical_hash.update(encoded)
        self.logical_bytes += len(encoded)
        self.records += 1

    def manifest(self):
        body = self.path.read_bytes()
        return {"path": self.path.name, "encoding": "gzip", "format": "ndjson",
                "records": self.records,
                "uncompressed_bytes": self.logical_bytes,
                "uncompressed_sha256": self.logical_hash.hexdigest(),
                "download_bytes": len(body), "download_sha256": stable_hash(body)}


def generate(directory, library):
    template = make_sample()
    scores, assignments, statuses, queues_at_risk = (Counter() for _ in range(4))
    normalized_models, plans = set(), set()
    evaluated_total = feasible_total = covered_total = preferences_satisfied = preference_misses = 0
    evaluations = []
    raw_archive, normalized_archive, native_archive, evidence_archive, assignment_archive = streams = [
        Archive(directory, name) for name in ARCHIVES
    ]
    with raw_archive, normalized_archive, native_archive, evidence_archive, assignment_archive:
        for seed in range(SCENARIO_COUNT):
            scenario, raw, changes = profile(seed, template)
            problem, screen, window_seconds, combinations = normalize(raw)
            native = native_solve(library, problem, raw["policy"]["evaluation_budget"])
            audit = enrich(raw, problem, native, screen, window_seconds, combinations)
            proof = audit["proof"]
            require(proof["status"] == "optimal_within_model" and
                    proof["independent_enumeration_matches_native"], "failed exact result verification")
            covered = audit["coverage"]["queues_with_an_eligible_assigned_operator"]
            raw_archive.write({"scenario_id": scenario, "availability_changes": changes, "raw_input": raw})
            normalized_archive.write({"scenario_id": scenario, "evaluation_budget": proof["budget_combinations"],
                                      "problem": problem})
            native_archive.write({"scenario_id": scenario, "status": proof["status"], "solution": native})
            evidence_archive.write({"scenario_id": scenario, "report": audit})
            for row in audit["queues"]:
                assignment_archive.write({
                    "scenario_id": scenario, "queue_id": row["queue_id"],
                    "operator_id": row["assigned_operator"],
                    "native_value": row["native_value"],
                    "eligible_operator_count": row["eligible_operator_count"],
                    "eligible_assignment": True,
                    "preferred_operator_id": row["preference"]["preferred_operator"],
                    "preference_met": row["preference"]["satisfied"],
                    "assigned_queue_soft_penalty": row["preference"]["soft_penalty"],
                    "scenario_hard_score": native["score"]["hard"],
                    "scenario_soft_score": native["score"]["soft"],
                    "expected_handling_seconds": row["demand_context"]["expected_handling_seconds"],
                    "probability_above_planned_capacity_basis_points": row["demand_context"][
                        "probability_above_planned_capacity_basis_points"
                    ],
                })
            covered_total += covered
            evaluated_total += proof["evaluated_combinations"]
            feasible_total += proof["hard_feasible_combinations"]
            evaluations.append(proof["evaluated_combinations"])
            preferences_satisfied += audit["constraint_verdicts"]["soft_preferences_met"]
            preference_misses += len(audit["constraint_verdicts"]["soft_preferences_missed"])
            scores[native["score"]["soft"]] += 1
            statuses[proof["status"]] += 1
            assignments.update(row["assigned_operator"] for row in audit["queues"])
            queues_at_risk.update(audit["coverage"]["queues_with_nonzero_demand_risk"])
            normalized_models.add(stable_hash(json_line(problem)))
            plans.add(tuple(native["values"]))
    require(covered_total == SCENARIO_COUNT * len(template["queues"]), "unexpected missing coverage")
    require(len(normalized_models) == SCENARIO_COUNT and len(plans) > 50, "scenario designs are not distinct enough")
    require(preferences_satisfied + preference_misses == covered_total and preference_misses > 0,
            "preference counts did not reconcile")
    report = {
        "schema_version": 1, "classification": "sample", "batch_id": "call-center-coverage-sample-batch-v1",
        "method": "separate bounded exact ABI v1 solves with independent exhaustive verification",
        "first_verified_engine_revision": SOURCE_REVISION, "native_abi_version": 1,
        "joint_solve": False, "throughput_benchmark": False, "scenarios": SCENARIO_COUNT,
        "queues_per_scenario": len(template["queues"]), "operator_profiles_per_scenario": len(template["operators"]),
        "covered_queue_assignments": covered_total,
        "distinct_normalized_problems": len(normalized_models), "distinct_assignment_vectors": len(plans),
        "scenario_status_counts": dict(statuses),
        "candidate_combinations_evaluated": {"total": evaluated_total, "per_scenario_min": min(evaluations),
                                              "per_scenario_max": max(evaluations)},
        "hard_feasible_candidate_combinations_total": feasible_total,
        "soft_preferences": {"satisfied": preferences_satisfied, "missed": preference_misses,
                             "soft_score_histogram": dict(sorted(scores.items()))},
        "assignment_count_by_operator_id": dict(sorted(assignments.items())),
        "scenario_count_above_zero_demand_risk_by_queue": dict(sorted(queues_at_risk.items())),
        "artifacts": [archive.manifest() for archive in streams],
    }
    (directory / "summary.json").write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--library", type=Path, required=True)
    parser.add_argument("--write", action="store_true", help="replace the checked-in sample archives")
    args = parser.parse_args()
    with TemporaryDirectory(prefix="call-center-batch-", dir=HERE) as temp:
        candidate = Path(temp)
        report = generate(candidate, args.library)
        for name in (*ARCHIVES, "summary.json"):
            artifact = candidate / name
            saved = HERE / name
            if args.write:
                artifact.replace(saved)
            else:
                require(artifact.read_bytes() == saved.read_bytes(), f"failed canonical verification: {name}")
    print(json.dumps({k: report[k] for k in ("scenarios", "covered_queue_assignments",
          "distinct_normalized_problems", "distinct_assignment_vectors",
          "candidate_combinations_evaluated", "soft_preferences")}, indent=2))


if __name__ == "__main__":
    main()
