# Call center coverage: 240 independent sample decisions

This batch varies one 30-minute coverage model over 240 independent sample
scenarios. Each scenario screens 60 operator profiles across six simultaneous
voice queues. They are separate, bounded exact searches, not one coupled
schedule and not a throughput benchmark. No profiles represent employees or
callers; the probability and demand figures are explicit modeling assumptions,
not measured traffic.

The batch varies eligible operators through temporary breaks and voice-seat
availability, and varies queue preference weights. It also varies typical and
surge arrival counts, scenario probabilities, handling times and occupancy
targets. Probabilities and demand calculations are contextual: the native
solver receives integer domains and rules, not the raw roster or probabilities.
The report shows the chance of exceeding planned handling capacity under each
queue's two assumed demand scenarios. It does not estimate waiting times or
assign incoming calls.

| Artifact | Records | What each record contains |
| --- | ---: | --- |
| `raw-input.ndjson.gz` | 240 | Scenario ID, availability changes, and raw profiles, queues, assumptions and metadata. |
| `normalized-problems.ndjson.gz` | 240 | Scenario ID, evaluation budget, and native ABI V1 problem. |
| `native-solutions.ndjson.gz` | 240 | Scenario ID, exact status, solution vector, scores, and evaluated combinations. |
| `enriched-output.ndjson.gz` | 240 | Scenario and queue evidence: eligibility and exclusions, assignments, demand calculations, rule verdicts and independent exact-search proof. |
| `assignments.ndjson.gz` | 1,440 | One row per selected queue/operator pair: availability outcome, preference/penalty, scenario scores and demand metrics. |
| `summary.json` | 1 | Totals, preference and score distribution, model and selected-vector diversity, and SHA-256 hashes of each download and its uncompressed records. |

All 240 scenarios cover every queue and have exact status
`optimal_within_model`. The 1,440 assignments come from 125 distinct selected
vectors across 240 distinct normalized problems. The native solver and an
independent Python enumeration agree on each result. Across scenarios, 180
preferences are missed while every hard constraint is satisfied. Each
reported assignment proves optimality only within its specific sample
scenario and search budget.

## Read and reproduce

Files are gzip-compressed UTF-8 newline-delimited JSON. Use `scenario_id` to
join streams. `queue_id` identifies a queue within a scenario. Raw operator
array positions are the integer coordinates of the normalized domains.

```sh
gzip -cd assignments.ndjson.gz | head -n 3
python -B verify_archives.py
python -B batch.py --library /path/to/engine/backend/target/release/liborchestrata_ffi.so
```

The archive verifier checks both SHA-256 hashes, row counts and identity, and
reconciles normalized models, chosen values, aggregate scores and output rows.
The batch script uses a real Orchestrata engine ABI V1 library on the machine.
It regenerates the scenarios, solves them through ctypes and checks each
result against an independent enumeration, then compares saved artifacts.
It uses Python 3.10+ and the system time-zone data; no extra Python packages
are needed. Gzip compression bytes can depend on zlib version; canonical
uncompressed NDJSON hashes are reported separately. Use `--write` only when
intentionally regenerating the sample files. The `common/` directory contains
the same reusable normalizer and native-proof code as the detailed
single-scenario example.
